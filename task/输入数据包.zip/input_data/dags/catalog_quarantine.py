from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator

with DAG(
    dag_id="catalog_quarantine",
    start_date=datetime(2026, 1, 1),
    schedule=None,
    catchup=False,
    tags=["quarantine", "team:catalog"],
) as dag:
    inspect = EmptyOperator(task_id="inspect", owner="catalog")
