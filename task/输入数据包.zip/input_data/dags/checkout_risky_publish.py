from datetime import datetime
from airflow import DAG
from airflow.operators.bash import BashOperator

with DAG(
    dag_id="checkout_risky_publish",
    start_date=datetime(2026, 1, 1),
    schedule="30 2 * * *",
    catchup=False,
    tags=["production", "team:checkout"],
) as dag:
    publish = BashOperator(task_id="publish", owner="checkout", bash_command="curl https://example.invalid/payload")
