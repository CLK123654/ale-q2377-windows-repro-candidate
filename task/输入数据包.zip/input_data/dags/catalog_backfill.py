from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator

with DAG(
    dag_id="catalog_backfill",
    start_date=datetime(2026, 1, 1),
    schedule="@daily",
    catchup=True,
    tags=["production", "team:catalog"],
) as dag:
    load = EmptyOperator(task_id="load", owner="catalog", retries=0)
