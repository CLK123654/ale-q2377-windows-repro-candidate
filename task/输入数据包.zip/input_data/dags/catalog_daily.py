from datetime import datetime, timedelta
from airflow import DAG
from airflow.operators.empty import EmptyOperator

with DAG(
    dag_id="catalog_daily",
    start_date=datetime(2026, 1, 1),
    schedule="15 1 * * *",
    catchup=False,
    tags=["production", "team:catalog"],
) as dag:
    extract = EmptyOperator(task_id="extract", owner="catalog", queue="legacy", retries=4, execution_timeout=timedelta(minutes=80))
    publish = EmptyOperator(task_id="publish", owner="catalog", queue="default", retries=1, execution_timeout=timedelta(minutes=20))
    extract >> publish
