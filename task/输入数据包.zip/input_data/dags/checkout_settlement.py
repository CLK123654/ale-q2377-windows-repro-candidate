from datetime import datetime
from airflow import DAG
from airflow.operators.empty import EmptyOperator

with DAG(
    dag_id="checkout_settlement",
    start_date=datetime(2026, 1, 1),
    schedule="0 3 * * *",
    catchup=False,
    tags=["production", "team:checkout"],
) as dag:
    settle = EmptyOperator(task_id="settle", owner="checkout", queue="finance", retries=1)
