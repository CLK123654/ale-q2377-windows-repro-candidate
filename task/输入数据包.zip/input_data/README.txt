共享Airflow平台策略交接材料

contracts/cluster_policy.json是平台团队给出的准入与任务属性合同。
registry/dag_inventory.json是本次接入清单，用于关联DAG文件、服务和业务团队。
dags目录是待接入的DAG源码包，所有文件都要进入Airflow解析流程。

材料为自造的脱敏工程样例，可以公开使用。输入目录只读。
